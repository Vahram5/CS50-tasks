SELECT title
FROM movies, people, stars
WHERE people.name = "Johnny Depp" AND people.id = stars.person_id AND stars.movie_id = movies.id
INTERSECT
SELECT title
FROM movies, people, stars
WHERE people.name = "Helena Bonham Carter" AND people.id = stars.person_id AND stars.movie_id = movies.id