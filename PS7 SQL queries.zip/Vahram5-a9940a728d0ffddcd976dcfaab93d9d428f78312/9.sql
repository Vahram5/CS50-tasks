SELECT name
FROM movies, stars, people
WHERE movies.year = 2004 AND stars.person_id = people.id AND stars.movie_id = movies.id
GROUP BY name, person_id
ORDER BY birth