-- Keep a log of any SQL queries you execute as you solve the mystery.

--SELECT description FROM crime_scene_reports WHERE month = 7 AND day = 28 AND year = 2021 AND street = "Humphrey Street"
--     Theft of the CS50 duck took place at 10:15am at the Humphrey Street bakery. Interviews were conducted today with three witnesses
--     who were present at the time – each of their interview transcripts mentions the bakery.

-- interviews
-- | Ruth    | Sometime within ten minutes of the theft, I saw the thief get into a car in the bakery parking lot and drive away.
            -- If you have security footage from the bakery parking lot, you might want to look for cars that left the parking lot in that time frame.                                                          |
-- | Eugene  | I don't know the thief's name, but it was someone I recognized. Earlier this morning, before I arrived at
            -- Emma's bakery, I was walking by the ATM on Leggett Street and saw the thief there withdrawing some money.                                                                                                 |
-- | Raymond | As the thief was leaving the bakery, they called someone who talked to them for less than a minute. In the call,
            -- I heard the thief say that they were planning to take the earliest flight out of Fiftyville tomorrow. The thief then asked the
            -- person on the other end of the phone to purchase the flight ticket. |


    -- SELECT name, amount FROM people
    -- JOIN bank_accounts ON bank_accounts.person_id = people.id
    -- JOIN atm_transactions ON atm_transactions.account_number = bank_accounts.account_number
    -- WHERE month = 7 AND day = 28 AND year = 2021 AND atm_transactions.transaction_type = "withdraw"
    -- GROUP BY name, people.id
    -- ORDER BY name;
--     +-----------+--------+
-- |   name    | amount |
-- +-----------+--------+
-- | Benista   | 30     |
-- | Bruce     | 50     |
-- | Carina    | 40     |
-- | Carol     | 40     |
-- | Charles   | 35     |
-- | Christian | 15     |
-- | Christina | 20     |
-- | Christine | 25     |
-- | David     | 40     |
-- | Denise    | 30     |
-- | Dennis    | 10     |
-- | Diana     | 35     |
-- | Donna     | 15     |
-- | Douglas   | 55     |
-- | Ernest    | 10     |
-- | Ethan     | 85     |
-- | Hannah    | 45     |
-- | Harold    | 50     |
-- | Iman      | 20     |
-- | Jack      | 20     |
-- | Janet     | 65     |
-- | Jennifer  | 95     |
-- | Jeremy    | 55     |
-- | Jesse     | 90     |
-- | Joan      | 20     |
-- | Joe       | 60     |
-- | Joshua    | 45     |
-- | Julia     | 5      |
-- | Keith     | 95     |
-- | Kenny     | 20     |
-- | Laura     | 40     |
-- | Lisa      | 100    |
-- | Luca      | 48     |
-- | Margaret  | 60     |
-- | Mark      | 15     |
-- | Michelle  | 5      |
-- | Nicholas  | 60     |
-- | Olivia    | 40     |
-- | Pamela    | 100    |
-- | Paul      | 100    |
-- | Rachel    | 35     |
-- | Rebecca   | 5      |
-- | Rose      | 55     |
-- | Ryan      | 10     |
-- | Samantha  | 25     |
-- | Sean      | 70     |
-- | Sharon    | 80     |
-- | Shirley   | 20     |
-- | Stephen   | 15     |
-- | Taylor    | 60     |
-- | Theresa   | 60     |
-- | Zachary   | 55     |


    -- SELECT name FROM people
    -- JOIN phone_calls ON phone_calls.caller = people.phone_number
    -- WHERE month = 7 AND day = 28 AND year = 2021 AND phone_calls.duration < 60
    -- GROUP BY name, people.id
    -- ORDER BY name;

    -- | Benista |
    -- | Bruce   |
    -- | Carina  |
    -- | Diana   |
    -- | Kelsey  |
    -- | Kenny   |
    -- | Sofia   |
    -- | Taylor  |

    -- SELECT name, amount FROM people
    -- JOIN bank_accounts ON bank_accounts.person_id = people.id
    -- JOIN atm_transactions ON atm_transactions.account_number = bank_accounts.account_number
    -- WHERE month = 7 AND day = 28 AND year = 2021 AND atm_transactions.transaction_type = "withdraw" AND
    -- name in (SELECT name FROM people
    -- JOIN phone_calls ON phone_calls.caller = people.phone_number
    -- WHERE month = 7 AND day = 28 AND year = 2021 AND phone_calls.duration < 60
    -- GROUP BY name, people.id)
    -- GROUP BY name, people.id
    -- ORDER BY name

    --     +---------+--------+
    -- |  name   | amount |
    -- +---------+--------+
    -- | Benista | 30     |
    -- | Bruce   | 50     |
    -- | Carina  | 40     |
    -- | Diana   | 35     |
    -- | Kenny   | 20     |
    -- | Taylor  | 60     |


    -- SELECT name FROM people
    -- JOIN passengers ON passengers.passport_number = people.passport_number
    -- JOIN flights ON flights.id = passengers.flight_id
    -- WHERE month = 7 AND day = 29 AND year = 2021 AND
    -- flights.origin_airport_id = 8 AND
    -- GROUP BY name, people.id
    -- ORDER BY name;

-- +-----------+
-- | Brandon   |
-- | Brooke    |
-- | Bruce     |
-- | Carol     |
-- | Charles   |
-- | Christian |
-- | Daniel    |
-- | Dennis    |
-- | Diana     |
-- | Doris     |
-- | Douglas   |
-- | Edward    |
-- | Emily     |
-- | Ethan     |
-- | Gloria    |
-- | Heather   |
-- | Jennifer  |
-- | John      |
-- | Jordan    |
-- | Jose      |
-- | Kelsey    |
-- | Kenny     |
-- | Kristina  |
-- | Larry     |
-- | Luca      |
-- | Marilyn   |
-- | Matthew   |
-- | Melissa   |
-- | Michael   |
-- | Pamela    |
-- | Rebecca   |
-- | Richard   |
-- | Sofia     |
-- | Sophia    |
-- | Steven    |
-- | Taylor    |
-- | Thomas    |
-- +-----------+



-- SELECT name FROM people
-- JOIN passengers ON passengers.passport_number = people.passport_number
-- JOIN flights ON flights.id = passengers.flight_id
-- WHERE month = 7 AND day = 29 AND year = 2021 AND
-- flights.origin_airport_id = 8 AND
-- name IN (SELECT name FROM people
-- JOIN phone_calls ON phone_calls.caller = people.phone_number
-- WHERE month = 7 AND day = 28 AND year = 2021 AND phone_calls.duration < 60
-- GROUP BY name, people.id)
-- GROUP BY name, people.id
-- ORDER BY name;

-- +--------+
-- | Bruce  |
-- | Diana  |
-- | Kelsey |
-- | Kenny  |
-- | Sofia  |
-- | Taylor |





-- SELECT name FROM people
-- JOIN passengers ON passengers.passport_number = people.passport_number
-- JOIN flights ON flights.id = passengers.flight_id
-- WHERE month = 7 AND day = 29 AND year = 2021 AND
-- flights.origin_airport_id = 8 AND
-- name IN(  SELECT name FROM people
--     JOIN bank_accounts ON bank_accounts.person_id = people.id
--     JOIN atm_transactions ON atm_transactions.account_number = bank_accounts.account_number
--     WHERE month = 7 AND day = 28 AND year = 2021 AND atm_transactions.transaction_type = "withdraw" AND
--     name in (SELECT name FROM people
--     JOIN phone_calls ON phone_calls.caller = people.phone_number
--     WHERE month = 7 AND day = 28 AND year = 2021 AND phone_calls.duration < 60
--     GROUP BY name, people.id)
--     GROUP BY name, people.id)
--     ORDER BY name

--     +--------+
-- |  name  |
-- +--------+
-- | Bruce  |
-- | Diana  |
-- | Kenny  |
-- | Taylor |
-- +--------+



-- SELECT name FROM people
-- JOIN bakery_security_logs ON bakery_security_logs.license_plate = people.license_plate
-- WHERE month = 7 AND day = 28 AND year = 2021 AND bakery_security_logs.hour = 10
-- AND bakery_security_logs.minute >= 15 AND bakery_security_logs.minute <= 25 AND
-- bakery_security_logs.activity = "exit" AND
--     name IN(SELECT name FROM people
--     JOIN passengers ON passengers.passport_number = people.passport_number
--     JOIN flights ON flights.id = passengers.flight_id
--     WHERE month = 7 AND day = 29 AND year = 2021 AND
--     flights.origin_airport_id = 8 AND
--         name IN(    SELECT name FROM people
--         JOIN bank_accounts ON bank_accounts.person_id = people.id
--         JOIN atm_transactions ON atm_transactions.account_number = bank_accounts.account_number
--         WHERE month = 7 AND day = 28 AND year = 2021 AND atm_transactions.transaction_type = "withdraw" AND
--             name in (    SELECT name FROM people
--             JOIN phone_calls ON phone_calls.caller = people.phone_number
--             WHERE month = 7 AND day = 28 AND year = 2021 AND phone_calls.duration < 60)))
-- ORDER BY name



-- origin_airport_id = 8 AND month = 7 AND day = 28 AND year = 2021 AND


SELECT full_name FROM airports
JOIN flights ON flights.destination_airport_id = airports.id
JOIN passengers ON passengers.flight_id = flights.destination_airport_id
JOIN people ON people.passport_number = passengers.passport_number
WHERE people.name = "Diana";

SELECT people.name, airports.full_name, airports.city FROM airports
JOIN flights ON flights.destination_airport_id = airports.id
JOIN passengers ON passengers.flight_id = flights.id
JOIN people ON people.passport_number = passengers.passport_number
WHERE flights.origin_airport_id = 8 AND flights.day = 29 AND flights.year = 2021 AND flights.month = 7
AND people.id IN (SELECT people.id FROM people
    JOIN bakery_security_logs ON bakery_security_logs.license_plate = people.license_plate
    WHERE month = 7 AND day = 28 AND year = 2021 AND bakery_security_logs.hour = 10
    AND bakery_security_logs.minute >= 15 AND bakery_security_logs.minute <= 25 AND
    bakery_security_logs.activity = "exit" AND
        people.id IN(SELECT people.id FROM people
        JOIN passengers ON passengers.passport_number = people.passport_number
        JOIN flights ON flights.id = passengers.flight_id
        WHERE month = 7 AND day = 29 AND year = 2021 AND
        flights.origin_airport_id = 8 AND
            people.id IN(SELECT people.id FROM people
            JOIN bank_accounts ON bank_accounts.person_id = people.id
            JOIN atm_transactions ON atm_transactions.account_number = bank_accounts.account_number
            WHERE month = 7 AND day = 28 AND year = 2021 AND atm_transactions.transaction_type = "withdraw" AND
                people.id in (SELECT people.id FROM people
                JOIN phone_calls ON phone_calls.caller = people.phone_number
                WHERE month = 7 AND day = 28 AND year = 2021 AND phone_calls.duration < 60))))


SELECT people.name FROM people
JOIN phone_calls ON phone_calls.caller = people.phone_number
WHERE people.id = 686048 AND month = 7 AND day = 28 AND year = 2021 AND phone_calls.duration < 60;